﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Office.Interop.Excel;
using Microsoft.Office.Interop;
using System.Diagnostics;

using _Excel = Microsoft.Office.Interop.Excel;


namespace ExcelTest
{
    public partial class Form1 : Form
    {
        _Excel.Application App;
        _Excel.Workbooks wbooks;
        _Excel.Workbook wbook;
        _Excel._Worksheet wsheet;
        _Excel.Range range;

        Timer cellcheck;

        public void GetCellVal()
        {
            List<string> list = new List<string>();
            _Excel.Worksheet ObjWorkSheet;
            ObjWorkSheet = (Microsoft.Office.Interop.Excel.Worksheet)wbook.Sheets[1];
            int numCol = 3;

            range = ObjWorkSheet.UsedRange.Columns[numCol];
            // range = ObjWorkSheet.UsedRange.Rows[numRow];
            System.Array myvalues = (System.Array)range.Cells.Value2;

            string[] strArray = myvalues.OfType<object>().Select(o => o.ToString()).ToArray();
           
            foreach(string s in strArray)
            {
                list.Add(s);
            }

            label4.Text = string.Join(Environment.NewLine, list);
            label5.Text = list.Count().ToString();
        }

        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            cellcheck = new Timer();
            cellcheck.Tick += CellChecker_Tick;
            if(textBox1.Text != "")
            {
                button1.Enabled = true;
            }
        }

        private void CellChecker_Tick(object s, EventArgs e)
        {
            try
            {
                GetCellVal();
                label3.Text = App.Selection.Value.ToString();
                

            }
            catch (Exception)
            {
            }
        }



        private void button2_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Excel File(.xlsx/.xls)|*.xlsx;*.xls";
            
            if(ofd.ShowDialog() == DialogResult.OK)
            {
                textBox1.Text = ofd.FileName;
            }
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            button1.Enabled = textBox1.Text != "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            App = new _Excel.Application();
            wbooks = App.Workbooks;
            wbook = wbooks.Open(textBox1.Text);
            App.Visible = true;
            cellcheck.Start();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            wsheet = wbook.ActiveSheet;

            string from = textBox2.Text;
            string to = textBox3.Text;

            int FromX = int.Parse(from.Split(',')[0]);
            int FromY = int.Parse(from.Split(',')[1]);

            int toX = int.Parse(to.Split(',')[0]);
            int toY = int.Parse(to.Split(',')[1]);

            for (int x = FromX; x < toX + 1; x++)
            {
                for (int y = FromY; y < toY + 1; y++)
                {
                    if(textBox4.Text != " " && textBox4.Text != string.Empty)
                    {
                        wsheet.Cells[x, y].Value = textBox4.Text;
                    }
                }
            }

        }
        private void Form1_FormClosing(Object sender, FormClosingEventArgs e)
        {
            App.Quit();
            foreach (Process proc in Process.GetProcessesByName("EXCEL"))
            {
                proc.Kill();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            App.Quit();
            wbooks.Close();
            label4.Text = "";
            label5.Text = "";
            foreach (Process proc in Process.GetProcessesByName("EXCEL"))
            {
                proc.Kill();
            }
        }
    }
}
